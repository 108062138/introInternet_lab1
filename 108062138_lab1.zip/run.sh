rm *.xml
make
./TCP_client.o can.cs.nthu.edu.tw/index.php > res.xml
cat res.xml